<!DOCTYPE html>
<html>
  <?php include("includes/header.php"); ?>
  <body id = "awards">
    <header class="header">
      <div class="csscontainer1">
        <img src="images/teamlogo.png" alt="teamlogo" id="teamlogo">
        <h1 class="title">Awards</h1>
        <img src="images/logo.png" alt="logo" id="logo">
      </div>
    </header>
    <?php include("includes/navigation.php"); ?>
    <!-- Beginning of page content -->
    <div class="awardscontainer">
    </div>
  </body>
</html>

<footer>
  <p>Email:  <a href="robomasterhkust@gmail.com">HKUST robomaster</a></p>
  <p>Address:7B, Shaw House, Clear Water Bay Road, Sai Kung, Kowloon, Hong Kong</p>
</footer>

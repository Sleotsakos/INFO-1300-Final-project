<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HKUST Robomaster</title>
  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
  <!-- Load jQuery -->
<script src="scripts/jquery-3.2.1.min.js" type="text/javascript"></script>
<!-- Load slideshow script-->
<script src="scripts/slideshow.js" type="text/javascript"></script>
</head>

<div class="menu">
<hr/>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="schedule.php">Schedule</a></li>
      <!-- <li><a href="forstudents.php">For Students</a></li> -->
      <li><a href="sponsors.php">Sponsors</a></li>
      <!-- <li><a href="awards.php">Awards</a></li> -->
      <li><a href="members.php">Members</a></li>
      <li><a href="contact.php">Contact</a><li>
    </ul>
  </nav>
<hr/>
</div>
